package main

import bot "eggexcutive-orders/informer/bot"

func main() {
	bot.BotToken = "MTMzMjIyNDM4MTc2MTYxNzk2MQ.GzXQEl.i0PN2VbQwuox4vYUsulgsoXK0eUzDlWfUoneZo"
	bot.Run() // call the run function of bot/bot.go
}
